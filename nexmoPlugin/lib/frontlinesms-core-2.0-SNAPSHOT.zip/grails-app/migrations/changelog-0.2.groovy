databaseChangeLog = {

	changeSet(author: "geoffrey (generated)", id: "1340692427901-1") {
		dropIndex(indexName: "TEXT_UNIQUE_1337355800008", tableName: "SYSTEM_NOTIFICATION")
	}
}
