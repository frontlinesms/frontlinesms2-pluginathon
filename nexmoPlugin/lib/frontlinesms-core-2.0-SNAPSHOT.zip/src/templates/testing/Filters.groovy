@artifact.package@

import grails.test.mixin.*

@Mock(@artifact.testclass@)
class @artifact.name@ {

    void testSomething() {
        fail "Implement me"
    }
}
