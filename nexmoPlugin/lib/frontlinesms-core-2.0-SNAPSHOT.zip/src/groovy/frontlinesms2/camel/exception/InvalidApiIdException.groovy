package frontlinesms2.camel.exception


class InvalidApiIdException extends RuntimeException {
	public InvalidApiIdException(String message) {
		super(message)
	}
}
