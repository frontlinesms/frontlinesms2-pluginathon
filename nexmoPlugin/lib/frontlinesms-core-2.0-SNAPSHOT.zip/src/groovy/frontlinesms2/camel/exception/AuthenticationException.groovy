package frontlinesms2.camel.exception


class AuthenticationException extends RuntimeException {
	public AuthenticationException(String message) {
		super(message)
	}
}
