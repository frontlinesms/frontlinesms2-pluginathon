package frontlinesms2

public enum DispatchStatus {
	PENDING,
	FAILED,
	SENT
}
