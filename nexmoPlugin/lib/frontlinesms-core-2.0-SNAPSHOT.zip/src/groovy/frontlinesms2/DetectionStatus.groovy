package frontlinesms2

enum DetectionStatus {
	RED, AMBER, GREEN;
}