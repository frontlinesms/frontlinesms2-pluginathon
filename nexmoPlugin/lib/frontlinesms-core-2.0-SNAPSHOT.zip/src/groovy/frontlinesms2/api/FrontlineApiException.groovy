package frontlinesms2.api

class FrontlineApiException extends RuntimeException {
	FrontlineApiException(String message) { super(message) }
}

